from __future__ import annotations

import os
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = PROJECT_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

import llm_api  # noqa: E402


class ProviderDetectionTests(unittest.TestCase):
    def test_known_endpoints(self) -> None:
        cases = {
            "https://api.openai.com/v1/chat/completions": "openai",
            "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions": "gemini",
            "https://api.anthropic.com/v1/messages": "anthropic",
            "https://api.deepseek.com/chat/completions": "deepseek",
            "https://ws-test.ap-southeast-1.maas.aliyuncs.com/compatible-mode/v1/chat/completions": "aliyun",
            "https://api.xiaomimimo.com/v1/chat/completions": "xiaomi",
        }
        for endpoint, expected in cases.items():
            with self.subTest(endpoint=endpoint):
                self.assertEqual(llm_api.detect_provider(endpoint), expected)

    def test_legacy_base_url_is_completed(self) -> None:
        self.assertEqual(
            llm_api._normalize_endpoint("https://api.openai.com/v1"),
            "https://api.openai.com/v1/chat/completions",
        )
        self.assertEqual(
            llm_api._normalize_endpoint("https://api.anthropic.com/v1"),
            "https://api.anthropic.com/v1/messages",
        )


class RequestMappingTests(unittest.TestCase):
    def setUp(self) -> None:
        self.settings = dict(llm_api.DEFAULT_SETTINGS)
        self.settings.update(
            {
                "provider": "openai",
                "endpoint": "https://api.openai.com/v1/chat/completions",
                "json_mode": "auto",
                "extra_body": {},
                "max_output_tokens": 200,
                "max_tokens_field": "auto",
            }
        )

    def test_xiaomi_uses_max_completion_tokens(self) -> None:
        settings = dict(self.settings)
        settings["provider"] = "xiaomi"
        body = llm_api._build_openai_compatible_body(
            settings=settings,
            model="mimo-v2.5-pro",
            temperature=0.2,
            system_prompt="system",
            payload={"x": 1},
            schema_name="test",
            output_schema={"type": "object"},
        )
        self.assertEqual(body["max_completion_tokens"], 200)
        self.assertNotIn("max_tokens", body)

    def test_xiaomi_api_key_header_without_bearer(self) -> None:
        settings = dict(self.settings)
        settings.update(
            {
                "provider": "xiaomi",
                "auth_header": "api-key",
                "auth_scheme": "none",
                "extra_headers": {},
            }
        )
        headers = llm_api._build_headers(settings, "secret")
        self.assertEqual(headers["api-key"], "secret")
        self.assertNotIn("Authorization", headers)

    def test_anthropic_mapping(self) -> None:
        settings = dict(self.settings)
        settings.update(
            {
                "provider": "anthropic",
                "anthropic_version": "2023-06-01",
                "auth_header": None,
                "auth_scheme": None,
                "extra_headers": {},
            }
        )
        headers = llm_api._build_headers(settings, "secret")
        self.assertEqual(headers["x-api-key"], "secret")
        self.assertEqual(headers["anthropic-version"], "2023-06-01")

        body = llm_api._build_anthropic_body(
            settings=settings,
            model="claude-test",
            temperature=0.2,
            system_prompt="system",
            payload={"x": 1},
        )
        self.assertEqual(body["system"], "system")
        self.assertEqual(body["messages"][0]["role"], "user")
        self.assertEqual(body["max_tokens"], 200)

    def test_json_fence_parser(self) -> None:
        parsed = llm_api._parse_json_from_model_text('```json\n{"ok": true}\n```')
        self.assertEqual(parsed, {"ok": True})


class EnvironmentResolutionTests(unittest.TestCase):
    def tearDown(self) -> None:
        llm_api.clear_api_settings_cache()

    def test_gemini_api_key_resolution(self) -> None:
        settings = dict(llm_api.DEFAULT_SETTINGS)
        settings["provider"] = "gemini"
        with patch.dict(os.environ, {"GEMINI_API_KEY": "gem-key"}, clear=True):
            self.assertEqual(llm_api.resolve_api_key(settings), "gem-key")

    def test_shared_key_has_priority(self) -> None:
        settings = dict(llm_api.DEFAULT_SETTINGS)
        settings["provider"] = "anthropic"
        with patch.dict(
            os.environ,
            {
                "RECRUITMENT_API_KEY": "shared",
                "ANTHROPIC_API_KEY": "anthropic",
            },
            clear=True,
        ):
            self.assertEqual(llm_api.resolve_api_key(settings), "shared")


class ProtocolExecutionTests(unittest.TestCase):
    class FakeClient:
        def __init__(self, responses):
            self.responses = list(responses)
            self.bodies = []

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def post(self, endpoint, headers, json):
            self.bodies.append(json)
            return self.responses.pop(0)

    @staticmethod
    def response(status: int, payload: dict) -> object:
        import httpx

        return httpx.Response(
            status,
            request=httpx.Request("POST", "https://example.test/v1/chat/completions"),
            json=payload,
        )

    def test_openai_compatible_retries_without_response_format(self) -> None:
        bad = self.response(
            400,
            {"error": {"message": "response_format is not supported"}},
        )
        good = self.response(
            200,
            {"choices": [{"message": {"content": "{\"ok\":true}"}}]},
        )
        client = self.FakeClient([bad, good])
        settings = dict(llm_api.DEFAULT_SETTINGS)
        settings.update(
            {
                "provider": "gemini",
                "endpoint": "https://example.test/v1/chat/completions",
                "max_retries": 0,
                "extra_body": {},
                "max_output_tokens": None,
                "json_mode": "auto",
            }
        )
        body = llm_api._build_openai_compatible_body(
            settings=settings,
            model="model",
            temperature=0.2,
            system_prompt="Return JSON",
            payload={"x": 1},
            schema_name="test",
            output_schema={"type": "object"},
        )
        with patch.object(llm_api, "_build_httpx_client", return_value=client):
            raw = llm_api._call_raw_text(
                settings=settings,
                headers={"Authorization": "Bearer secret"},
                body=body,
            )
        self.assertEqual(raw, '{"ok":true}')
        self.assertIn("response_format", client.bodies[0])
        self.assertNotIn("response_format", client.bodies[1])

    def test_anthropic_content_block_extraction(self) -> None:
        good = self.response(
            200,
            {"content": [{"type": "text", "text": "{\"ok\":true}"}]},
        )
        client = self.FakeClient([good])
        settings = dict(llm_api.DEFAULT_SETTINGS)
        settings.update(
            {
                "provider": "anthropic",
                "endpoint": "https://api.anthropic.com/v1/messages",
                "max_retries": 0,
            }
        )
        with patch.object(llm_api, "_build_httpx_client", return_value=client):
            raw = llm_api._call_raw_text(
                settings=settings,
                headers={"x-api-key": "secret"},
                body={"model": "claude", "max_tokens": 10, "messages": []},
            )
        self.assertEqual(raw, '{"ok":true}')


if __name__ == "__main__":
    unittest.main()

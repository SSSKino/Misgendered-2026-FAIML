from __future__ import annotations

import argparse
import json
from pathlib import Path

from llm_api import (
    call_structured_json,
    get_api_endpoint,
    get_api_provider,
    get_default_model,
    get_default_temperature,
)

TEST_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "status": {"type": "string"},
        "answer": {"type": "string"},
    },
    "required": ["status", "answer"],
}


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Test the configured OpenAI/Gemini/Anthropic/DeepSeek/Aliyun/Xiaomi endpoint."
    )
    parser.add_argument(
        "--prompt",
        default="Reply with status=ok and answer=OK.",
        help="Short test prompt.",
    )
    parser.add_argument("--model", default=get_default_model())
    parser.add_argument("--temperature", type=float, default=get_default_temperature())
    parser.add_argument(
        "--raw-output",
        default="data/outputs/api_connection_test.raw.txt",
        help="Where to save a non-JSON provider response.",
    )
    args = parser.parse_args()

    print(f"provider: {get_api_provider()}")
    print(f"endpoint: {get_api_endpoint()}")
    print(f"model: {args.model}")

    result = call_structured_json(
        instructions=(
            "This is an API connectivity test. Return a tiny JSON object and do not "
            "perform any other task."
        ),
        payload={"prompt": args.prompt},
        schema_name="api_connection_test",
        schema_description="Minimal provider connectivity response",
        output_schema=TEST_SCHEMA,
        raw_fallback_name=str(Path(args.raw_output)),
        model=args.model,
        temperature=args.temperature,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

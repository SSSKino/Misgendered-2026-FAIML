from __future__ import annotations

import argparse
import json
import os
import random
import re
import sys
import time
from copy import deepcopy
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Optional
from urllib.parse import urlparse

import httpx
from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parent.parent
CONFIG_DIR = PROJECT_ROOT / "config"
ENV_PATHS = [PROJECT_ROOT / ".env", CONFIG_DIR / ".env"]
for _env_path in ENV_PATHS:
    if _env_path.exists():
        load_dotenv(_env_path, override=False)

DEFAULT_ENDPOINT = "https://api.openai.com/v1/chat/completions"
DEFAULT_SETTINGS: Dict[str, Any] = {
    "provider": "auto",
    "endpoint": DEFAULT_ENDPOINT,
    "model": "gpt-5.2",
    "temperature": 0.2,
    "max_output_tokens": None,
    "max_tokens_field": "auto",
    "timeout": 120.0,
    "connect_timeout": 20.0,
    "max_retries": 2,
    "json_mode": "auto",
    "verify_tls": True,
    "proxy": None,
    "organization": None,
    "project": None,
    "auth_header": None,
    "auth_scheme": None,
    "anthropic_version": "2023-06-01",
    "extra_headers": {},
    "extra_body": {},
}

_PROVIDER_API_KEY_ENV: Dict[str, tuple[str, ...]] = {
    "openai": ("OPENAI_API_KEY",),
    "gemini": ("GEMINI_API_KEY", "GOOGLE_API_KEY"),
    "anthropic": ("ANTHROPIC_API_KEY",),
    "deepseek": ("DEEPSEEK_API_KEY",),
    "aliyun": ("DASHSCOPE_API_KEY", "ALIYUN_API_KEY"),
    "xiaomi": ("MIMO_API_KEY", "XIAOMI_MIMO_API_KEY"),
    "openai_compatible": ("OPENAI_API_KEY",),
}

_RETRYABLE_STATUS_CODES = {408, 409, 425, 429, 500, 502, 503, 504}
_COMPATIBILITY_STATUS_CODES = {400, 404, 405, 415, 422, 501}


class LLMAPIError(RuntimeError):
    """Raised when an LLM endpoint cannot return a usable response."""


class LLMHTTPError(LLMAPIError):
    def __init__(
        self,
        *,
        status_code: int,
        provider: str,
        endpoint: str,
        response_text: str,
    ) -> None:
        preview = _clip_text(response_text, 2500)
        super().__init__(
            f"{provider} API returned HTTP {status_code} for {endpoint}: {preview}"
        )
        self.status_code = status_code
        self.provider = provider
        self.endpoint = endpoint
        self.response_text = response_text


def _clean_optional(value: Any) -> Any:
    if value in (None, "", "null", "None"):
        return None
    return value


def _parse_bool(value: Any, default: bool) -> bool:
    if value is None or value == "":
        return default
    if isinstance(value, bool):
        return value
    normalized = str(value).strip().lower()
    if normalized in {"1", "true", "yes", "y", "on"}:
        return True
    if normalized in {"0", "false", "no", "n", "off"}:
        return False
    raise ValueError(f"Invalid boolean value: {value!r}")


def _parse_json_object(value: Optional[str], *, field_name: str) -> Dict[str, Any]:
    if not value:
        return {}
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError as exc:
        raise ValueError(f"{field_name} must be a valid JSON object") from exc
    if not isinstance(parsed, dict):
        raise ValueError(f"{field_name} must be a JSON object")
    return parsed


def _normalize_endpoint(value: Optional[str]) -> str:
    endpoint = str(value or DEFAULT_ENDPOINT).strip()
    if not endpoint:
        endpoint = DEFAULT_ENDPOINT
    endpoint = endpoint.rstrip("/")

    parsed = urlparse(endpoint)
    path = parsed.path.rstrip("/")
    if path.endswith("/chat/completions") or path.endswith("/messages"):
        return endpoint
    if path.endswith("/responses"):
        # The shared experiment runner targets Chat Completions / Messages.
        return endpoint[: -len("/responses")] + "/chat/completions"

    host = (parsed.hostname or "").lower()
    if "anthropic.com" in host:
        if path.endswith("/v1"):
            return endpoint + "/messages"
        return endpoint + "/v1/messages"

    return endpoint + "/chat/completions"


def _endpoint_from_legacy_base_url(base_url: Optional[str]) -> Optional[str]:
    if not base_url:
        return None
    return _normalize_endpoint(base_url)


def detect_provider(endpoint: str, explicit_provider: Optional[str] = None) -> str:
    requested = str(explicit_provider or "auto").strip().lower().replace("-", "_")
    aliases = {
        "google": "gemini",
        "claude": "anthropic",
        "dashscope": "aliyun",
        "qwen": "aliyun",
        "mimo": "xiaomi",
        "xiaomi_mimo": "xiaomi",
        "compatible": "openai_compatible",
        "openai_compatible": "openai_compatible",
    }
    requested = aliases.get(requested, requested)
    if requested and requested != "auto":
        if requested not in _PROVIDER_API_KEY_ENV:
            allowed = ", ".join(sorted(_PROVIDER_API_KEY_ENV))
            raise ValueError(
                f"Unsupported RECRUITMENT_API_PROVIDER={requested!r}. Allowed: auto, {allowed}"
            )
        return requested

    parsed = urlparse(endpoint)
    host = (parsed.hostname or "").lower()
    path = parsed.path.lower()
    if path.endswith("/messages") or "anthropic.com" in host:
        return "anthropic"
    if "generativelanguage.googleapis.com" in host:
        return "gemini"
    if "api.deepseek.com" in host:
        return "deepseek"
    if "aliyuncs.com" in host or "dashscope.aliyuncs.com" in host:
        return "aliyun"
    if "xiaomimimo.com" in host or "mimo.mi.com" in host:
        return "xiaomi"
    if "api.openai.com" in host:
        return "openai"
    return "openai_compatible"


def _load_endpoint() -> str:
    explicit_endpoint = (
        os.getenv("RECRUITMENT_API_URL")
        or os.getenv("RECRUITMENT_API_ENDPOINT")
        or os.getenv("LLM_API_URL")
    )
    if explicit_endpoint:
        return _normalize_endpoint(explicit_endpoint)

    legacy_base = os.getenv("RECRUITMENT_API_BASE_URL") or os.getenv("OPENAI_BASE_URL")
    return _endpoint_from_legacy_base_url(legacy_base) or DEFAULT_ENDPOINT


@lru_cache(maxsize=1)
def load_api_settings() -> Dict[str, Any]:
    settings = dict(DEFAULT_SETTINGS)
    settings["endpoint"] = _load_endpoint()

    env_overrides: Dict[str, Any] = {
        "provider": os.getenv("RECRUITMENT_API_PROVIDER"),
        "model": os.getenv("RECRUITMENT_API_MODEL") or os.getenv("OPENAI_MODEL"),
        "temperature": os.getenv("RECRUITMENT_API_TEMPERATURE")
        or os.getenv("OPENAI_TEMPERATURE"),
        "max_output_tokens": os.getenv("RECRUITMENT_API_MAX_OUTPUT_TOKENS")
        or os.getenv("OPENAI_MAX_OUTPUT_TOKENS"),
        "max_tokens_field": os.getenv("RECRUITMENT_API_MAX_TOKENS_FIELD"),
        "timeout": os.getenv("RECRUITMENT_API_TIMEOUT") or os.getenv("OPENAI_TIMEOUT"),
        "connect_timeout": os.getenv("RECRUITMENT_API_CONNECT_TIMEOUT"),
        "max_retries": os.getenv("RECRUITMENT_API_MAX_RETRIES")
        or os.getenv("OPENAI_MAX_RETRIES"),
        "json_mode": os.getenv("RECRUITMENT_API_JSON_MODE"),
        "verify_tls": os.getenv("RECRUITMENT_API_VERIFY_TLS"),
        "proxy": os.getenv("RECRUITMENT_API_PROXY"),
        "organization": os.getenv("OPENAI_ORG_ID") or os.getenv("RECRUITMENT_API_ORG"),
        "project": os.getenv("OPENAI_PROJECT") or os.getenv("RECRUITMENT_API_PROJECT"),
        "auth_header": os.getenv("RECRUITMENT_API_AUTH_HEADER"),
        "auth_scheme": os.getenv("RECRUITMENT_API_AUTH_SCHEME"),
        "anthropic_version": os.getenv("RECRUITMENT_API_ANTHROPIC_VERSION"),
    }
    for key, value in env_overrides.items():
        if value is not None:
            settings[key] = value

    settings["provider"] = detect_provider(
        settings["endpoint"], explicit_provider=settings.get("provider")
    )
    settings["temperature"] = float(settings["temperature"])
    settings["timeout"] = float(settings["timeout"])
    settings["connect_timeout"] = float(settings["connect_timeout"])
    settings["max_retries"] = max(0, int(settings["max_retries"]))
    settings["verify_tls"] = _parse_bool(settings.get("verify_tls"), True)

    if settings.get("max_output_tokens") is not None:
        settings["max_output_tokens"] = int(settings["max_output_tokens"])
        if settings["max_output_tokens"] <= 0:
            raise ValueError("RECRUITMENT_API_MAX_OUTPUT_TOKENS must be positive")

    settings["json_mode"] = str(settings["json_mode"] or "auto").strip().lower()
    if settings["json_mode"] not in {"auto", "json_object", "json_schema", "none"}:
        raise ValueError(
            "RECRUITMENT_API_JSON_MODE must be auto, json_object, json_schema, or none"
        )

    settings["max_tokens_field"] = str(
        settings["max_tokens_field"] or "auto"
    ).strip()
    if settings["max_tokens_field"] not in {
        "auto",
        "max_tokens",
        "max_completion_tokens",
    }:
        raise ValueError(
            "RECRUITMENT_API_MAX_TOKENS_FIELD must be auto, max_tokens, or max_completion_tokens"
        )

    for key in (
        "proxy",
        "organization",
        "project",
        "auth_header",
        "anthropic_version",
    ):
        settings[key] = _clean_optional(settings.get(key))

    # Preserve an explicitly empty auth scheme so providers such as Xiaomi can
    # send `api-key: <key>` instead of `Authorization: Bearer <key>`.
    raw_auth_scheme = settings.get("auth_scheme")
    if raw_auth_scheme in ("null", "None"):
        settings["auth_scheme"] = None
    elif raw_auth_scheme is not None:
        settings["auth_scheme"] = str(raw_auth_scheme).strip()

    settings["extra_headers"] = _parse_json_object(
        os.getenv("RECRUITMENT_API_EXTRA_HEADERS_JSON"),
        field_name="RECRUITMENT_API_EXTRA_HEADERS_JSON",
    )
    settings["extra_body"] = _parse_json_object(
        os.getenv("RECRUITMENT_API_EXTRA_BODY_JSON"),
        field_name="RECRUITMENT_API_EXTRA_BODY_JSON",
    )
    return settings


def clear_api_settings_cache() -> None:
    """Clear cached settings. Mainly useful for tests and interactive sessions."""

    load_api_settings.cache_clear()


def resolve_api_key(settings: Optional[Mapping[str, Any]] = None) -> str:
    current = dict(settings or load_api_settings())
    provider = str(current["provider"])

    names: list[str] = ["RECRUITMENT_API_KEY"]
    names.extend(_PROVIDER_API_KEY_ENV.get(provider, ()))
    names.extend(["OPENAI_API_KEY", "LLM_API_KEY"])

    seen: set[str] = set()
    ordered_names = [name for name in names if not (name in seen or seen.add(name))]
    for name in ordered_names:
        value = os.getenv(name)
        if value and value.strip():
            return value.strip()

    raise ValueError(
        "Missing API key for provider "
        f"{provider!r}. Set RECRUITMENT_API_KEY or one of: "
        + ", ".join(ordered_names)
    )


def get_default_model() -> str:
    return str(load_api_settings()["model"])


def get_default_temperature() -> float:
    return float(load_api_settings()["temperature"])


def get_api_endpoint() -> str:
    return str(load_api_settings()["endpoint"])


def get_api_provider() -> str:
    return str(load_api_settings()["provider"])


def _clip_text(text: Any, limit: int) -> str:
    value = str(text or "")
    if len(value) <= limit:
        return value
    return value[:limit] + "...<truncated>"


def _redact_url(url: Optional[str]) -> Optional[str]:
    if not url:
        return None
    parsed = urlparse(url)
    if not parsed.username and not parsed.password:
        return url
    host = parsed.hostname or ""
    if parsed.port:
        host = f"{host}:{parsed.port}"
    return parsed._replace(netloc=f"***:***@{host}").geturl()


def redacted_api_settings() -> Dict[str, Any]:
    settings = deepcopy(load_api_settings())
    settings["proxy"] = _redact_url(settings.get("proxy"))
    settings["extra_headers"] = {
        key: "***" if "key" in key.lower() or "authorization" in key.lower() else value
        for key, value in settings.get("extra_headers", {}).items()
    }
    return settings


def _deep_merge(base: Dict[str, Any], overlay: Mapping[str, Any]) -> Dict[str, Any]:
    merged = deepcopy(base)
    for key, value in overlay.items():
        if (
            key in merged
            and isinstance(merged[key], dict)
            and isinstance(value, Mapping)
        ):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = deepcopy(value)
    return merged


def _build_headers(settings: Mapping[str, Any], api_key: str) -> Dict[str, str]:
    provider = str(settings["provider"])
    headers: Dict[str, str] = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "misgendered-recruitment-evaluator/2.0",
    }

    if provider == "anthropic":
        auth_header = str(settings.get("auth_header") or "x-api-key")
        auth_scheme = settings.get("auth_scheme")
        if isinstance(auth_scheme, str) and auth_scheme.lower() in {"none", "raw"}:
            auth_scheme = ""
        auth_value = f"{auth_scheme} {api_key}".strip() if auth_scheme else api_key
        headers[auth_header] = auth_value
        headers["anthropic-version"] = str(
            settings.get("anthropic_version") or "2023-06-01"
        )
    else:
        auth_header = str(settings.get("auth_header") or "Authorization")
        auth_scheme = settings.get("auth_scheme")
        if auth_scheme is None:
            auth_scheme = "Bearer"
        elif isinstance(auth_scheme, str) and auth_scheme.lower() in {"none", "raw"}:
            auth_scheme = ""
        auth_value = f"{auth_scheme} {api_key}".strip() if auth_scheme else api_key
        headers[auth_header] = auth_value

        if provider == "openai":
            if settings.get("organization"):
                headers["OpenAI-Organization"] = str(settings["organization"])
            if settings.get("project"):
                headers["OpenAI-Project"] = str(settings["project"])

    for key, value in settings.get("extra_headers", {}).items():
        headers[str(key)] = str(value)
    return headers


def _schema_prompt(
    *,
    instructions: str,
    schema_name: str,
    schema_description: str,
    output_schema: Mapping[str, Any],
) -> str:
    schema_json = json.dumps(output_schema, ensure_ascii=False, separators=(",", ":"))
    return (
        instructions.rstrip()
        + "\n\nOUTPUT CONTRACT:\n"
        + "Return exactly one valid JSON object. Do not use markdown fences or add explanatory text.\n"
        + f"Schema name: {schema_name}\n"
        + f"Schema description: {schema_description}\n"
        + "The JSON object must conform to this JSON Schema:\n"
        + schema_json
    )


def _choose_json_mode(settings: Mapping[str, Any]) -> str:
    configured = str(settings.get("json_mode") or "auto")
    if configured != "auto":
        return configured
    # json_object is the broadest common denominator across OpenAI-compatible
    # providers. The local result normalizer still validates the complete schema.
    return "json_object"


def _choose_max_tokens_field(
    settings: Mapping[str, Any], *, provider: str, model: str
) -> str:
    configured = str(settings.get("max_tokens_field") or "auto")
    if configured != "auto":
        return configured
    lower_model = model.lower()
    if provider == "xiaomi":
        return "max_completion_tokens"
    if provider == "openai" and lower_model.startswith(("gpt-5", "o1", "o3", "o4")):
        return "max_completion_tokens"
    return "max_tokens"


def _build_openai_compatible_body(
    *,
    settings: Mapping[str, Any],
    model: str,
    temperature: float,
    system_prompt: str,
    payload: Any,
    schema_name: str,
    output_schema: Mapping[str, Any],
) -> Dict[str, Any]:
    body: Dict[str, Any] = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": json.dumps(payload, ensure_ascii=False),
            },
        ],
        "temperature": temperature,
        "stream": False,
    }

    json_mode = _choose_json_mode(settings)
    if json_mode == "json_object":
        body["response_format"] = {"type": "json_object"}
    elif json_mode == "json_schema":
        body["response_format"] = {
            "type": "json_schema",
            "json_schema": {
                "name": schema_name,
                "strict": True,
                "schema": output_schema,
            },
        }

    max_output_tokens = settings.get("max_output_tokens")
    if max_output_tokens is not None:
        field = _choose_max_tokens_field(
            settings, provider=str(settings["provider"]), model=model
        )
        body[field] = int(max_output_tokens)

    return _deep_merge(body, settings.get("extra_body", {}))


def _build_anthropic_body(
    *,
    settings: Mapping[str, Any],
    model: str,
    temperature: float,
    system_prompt: str,
    payload: Any,
) -> Dict[str, Any]:
    body: Dict[str, Any] = {
        "model": model,
        # Anthropic requires max_tokens. Use a safe default when the shared
        # setting is omitted.
        "max_tokens": int(settings.get("max_output_tokens") or 4096),
        "temperature": temperature,
        "system": system_prompt,
        "messages": [
            {
                "role": "user",
                "content": json.dumps(payload, ensure_ascii=False),
            }
        ],
    }
    return _deep_merge(body, settings.get("extra_body", {}))


def _body_signature(body: Mapping[str, Any]) -> str:
    return json.dumps(body, sort_keys=True, ensure_ascii=False, default=str)


def _openai_compatibility_variants(
    body: Dict[str, Any], settings: Mapping[str, Any]
) -> Iterable[Dict[str, Any]]:
    variants: list[Dict[str, Any]] = [deepcopy(body)]

    no_response_format = deepcopy(body)
    no_response_format.pop("response_format", None)
    variants.append(no_response_format)

    no_temperature = deepcopy(no_response_format)
    no_temperature.pop("temperature", None)
    variants.append(no_temperature)

    max_output_tokens = settings.get("max_output_tokens")
    if max_output_tokens is not None:
        alternate = deepcopy(no_temperature)
        if "max_tokens" in alternate:
            alternate["max_completion_tokens"] = alternate.pop("max_tokens")
        elif "max_completion_tokens" in alternate:
            alternate["max_tokens"] = alternate.pop("max_completion_tokens")
        variants.append(alternate)

    seen: set[str] = set()
    for variant in variants:
        signature = _body_signature(variant)
        if signature in seen:
            continue
        seen.add(signature)
        yield variant


def _is_parameter_compatibility_error(response: httpx.Response) -> bool:
    if response.status_code not in _COMPATIBILITY_STATUS_CODES:
        return False
    text = response.text.lower()
    keywords = (
        "response_format",
        "json_schema",
        "structured output",
        "unknown parameter",
        "unsupported parameter",
        "not supported",
        "temperature",
        "max_tokens",
        "max_completion_tokens",
        "invalid_request_error",
        "unrecognized",
    )
    return any(keyword in text for keyword in keywords)


def _build_httpx_client(settings: Mapping[str, Any]) -> httpx.Client:
    timeout = httpx.Timeout(
        timeout=float(settings["timeout"]),
        connect=float(settings["connect_timeout"]),
        read=float(settings["timeout"]),
        write=float(settings["timeout"]),
        pool=float(settings["connect_timeout"]),
    )
    kwargs: Dict[str, Any] = {
        "timeout": timeout,
        "verify": bool(settings["verify_tls"]),
        "follow_redirects": True,
        "trust_env": settings.get("proxy") is None,
    }
    proxy = settings.get("proxy")
    if proxy:
        try:
            return httpx.Client(proxy=str(proxy), **kwargs)
        except TypeError:
            return httpx.Client(
                proxies={"http://": str(proxy), "https://": str(proxy)},
                **kwargs,
            )
    return httpx.Client(**kwargs)


def _sleep_before_retry(attempt_index: int, response: Optional[httpx.Response] = None) -> None:
    retry_after: Optional[float] = None
    if response is not None:
        raw_retry_after = response.headers.get("retry-after")
        if raw_retry_after:
            try:
                retry_after = float(raw_retry_after)
            except ValueError:
                retry_after = None
    delay = retry_after if retry_after is not None else min(8.0, 0.75 * (2**attempt_index))
    delay += random.uniform(0.0, 0.2)
    time.sleep(delay)


def _post_body(
    *,
    client: httpx.Client,
    settings: Mapping[str, Any],
    headers: Mapping[str, str],
    body: Mapping[str, Any],
) -> httpx.Response:
    endpoint = str(settings["endpoint"])
    provider = str(settings["provider"])
    max_retries = int(settings["max_retries"])

    last_transport_error: Optional[Exception] = None
    for attempt in range(max_retries + 1):
        try:
            response = client.post(endpoint, headers=dict(headers), json=dict(body))
        except httpx.TransportError as exc:
            last_transport_error = exc
            if attempt >= max_retries:
                raise LLMAPIError(
                    f"{provider} network/proxy/TLS error while calling {endpoint}: "
                    f"{exc.__class__.__name__}: {exc}"
                ) from exc
            _sleep_before_retry(attempt)
            continue

        if response.status_code < 400:
            return response
        if response.status_code in _RETRYABLE_STATUS_CODES and attempt < max_retries:
            _sleep_before_retry(attempt, response)
            continue
        return response

    raise LLMAPIError(
        f"{provider} request failed after retries: {last_transport_error}"
    )


def _extract_openai_text(response_json: Mapping[str, Any]) -> str:
    choices = response_json.get("choices")
    if not isinstance(choices, list) or not choices:
        raise LLMAPIError(
            "OpenAI-compatible response does not contain choices[0]: "
            + _clip_text(json.dumps(response_json, ensure_ascii=False), 2000)
        )
    first = choices[0]
    if not isinstance(first, Mapping):
        raise LLMAPIError("OpenAI-compatible choices[0] is not an object")
    message = first.get("message")
    if not isinstance(message, Mapping):
        raise LLMAPIError("OpenAI-compatible choices[0].message is missing")
    content = message.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, Mapping):
                if item.get("type") in {"text", "output_text"}:
                    parts.append(str(item.get("text", "")))
                elif isinstance(item.get("content"), str):
                    parts.append(str(item["content"]))
            elif item is not None:
                parts.append(str(item))
        return "".join(parts)
    if content is None and isinstance(message.get("reasoning_content"), str):
        # Some reasoning-compatible gateways expose only reasoning_content on
        # malformed responses. Keep the error informative rather than silently
        # returning an empty string.
        raise LLMAPIError(
            "The provider returned reasoning_content but no final message.content"
        )
    return str(content or "")


def _extract_anthropic_text(response_json: Mapping[str, Any]) -> str:
    content = response_json.get("content")
    if not isinstance(content, list):
        raise LLMAPIError(
            "Anthropic response does not contain a content block array: "
            + _clip_text(json.dumps(response_json, ensure_ascii=False), 2000)
        )
    parts: list[str] = []
    for block in content:
        if isinstance(block, Mapping) and block.get("type") == "text":
            parts.append(str(block.get("text", "")))
    text = "".join(parts)
    if not text:
        raise LLMAPIError("Anthropic response contains no text content block")
    return text


def _decode_response_json(response: httpx.Response) -> Dict[str, Any]:
    try:
        payload = response.json()
    except ValueError as exc:
        raise LLMAPIError(
            "API returned a non-JSON HTTP response: " + _clip_text(response.text, 2500)
        ) from exc
    if not isinstance(payload, dict):
        raise LLMAPIError("API response body must be a JSON object")
    return payload


def _call_raw_text(
    *,
    settings: Mapping[str, Any],
    headers: Mapping[str, str],
    body: Dict[str, Any],
) -> str:
    provider = str(settings["provider"])
    endpoint = str(settings["endpoint"])

    with _build_httpx_client(settings) as client:
        if provider == "anthropic":
            response = _post_body(
                client=client,
                settings=settings,
                headers=headers,
                body=body,
            )
            if response.status_code >= 400:
                raise LLMHTTPError(
                    status_code=response.status_code,
                    provider=provider,
                    endpoint=endpoint,
                    response_text=response.text,
                )
            return _extract_anthropic_text(_decode_response_json(response))

        last_response: Optional[httpx.Response] = None
        for index, variant in enumerate(_openai_compatibility_variants(body, settings)):
            response = _post_body(
                client=client,
                settings=settings,
                headers=headers,
                body=variant,
            )
            last_response = response
            if response.status_code < 400:
                return _extract_openai_text(_decode_response_json(response))
            if index < 3 and _is_parameter_compatibility_error(response):
                continue
            raise LLMHTTPError(
                status_code=response.status_code,
                provider=provider,
                endpoint=endpoint,
                response_text=response.text,
            )

        assert last_response is not None
        raise LLMHTTPError(
            status_code=last_response.status_code,
            provider=provider,
            endpoint=endpoint,
            response_text=last_response.text,
        )


def _strip_markdown_fence(raw: str) -> str:
    text = raw.strip()
    fenced = re.fullmatch(
        r"```(?:json)?\s*(.*?)\s*```", text, flags=re.IGNORECASE | re.DOTALL
    )
    return fenced.group(1).strip() if fenced else text


def _parse_json_from_model_text(raw: str) -> Any:
    text = _strip_markdown_fence(raw)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        decoder = json.JSONDecoder()
        for index, char in enumerate(text):
            if char not in "[{":
                continue
            try:
                value, _ = decoder.raw_decode(text[index:])
                return value
            except json.JSONDecodeError:
                continue
        raise


def _write_raw_fallback(raw_fallback_name: str, raw: str) -> Path:
    target = Path(raw_fallback_name)
    target.parent.mkdir(parents=True, exist_ok=True)
    # Avoid concurrent workers overwriting each other's diagnostic response.
    if target.exists():
        target = target.with_name(
            f"{target.stem}.{os.getpid()}.{time.time_ns()}{target.suffix}"
        )
    target.write_text(raw or "", encoding="utf-8")
    return target


def call_structured_json(
    *,
    instructions: str,
    payload: Any,
    schema_name: str,
    schema_description: str,
    output_schema: Dict[str, Any],
    raw_fallback_name: str,
    model: Optional[str] = None,
    temperature: Optional[float] = None,
) -> Dict[str, Any]:
    settings = load_api_settings()
    chosen_model = model or str(settings["model"])
    chosen_temperature = float(
        settings["temperature"] if temperature is None else temperature
    )
    api_key = resolve_api_key(settings)
    headers = _build_headers(settings, api_key)
    system_prompt = _schema_prompt(
        instructions=instructions,
        schema_name=schema_name,
        schema_description=schema_description,
        output_schema=output_schema,
    )

    if settings["provider"] == "anthropic":
        request_body = _build_anthropic_body(
            settings=settings,
            model=chosen_model,
            temperature=chosen_temperature,
            system_prompt=system_prompt,
            payload=payload,
        )
    else:
        request_body = _build_openai_compatible_body(
            settings=settings,
            model=chosen_model,
            temperature=chosen_temperature,
            system_prompt=system_prompt,
            payload=payload,
            schema_name=schema_name,
            output_schema=output_schema,
        )

    raw = _call_raw_text(
        settings=settings,
        headers=headers,
        body=request_body,
    )
    try:
        parsed = _parse_json_from_model_text(raw)
    except Exception as exc:
        saved_path = _write_raw_fallback(raw_fallback_name, raw)
        raise ValueError(
            f"Model returned non-JSON text. Saved to {saved_path}"
        ) from exc
    if not isinstance(parsed, dict):
        saved_path = _write_raw_fallback(raw_fallback_name, raw)
        raise ValueError(
            f"Model output must be a JSON object, got {type(parsed).__name__}. "
            f"Saved to {saved_path}"
        )
    return parsed


def _main() -> int:
    parser = argparse.ArgumentParser(
        description="Show the resolved multi-provider LLM API configuration."
    )
    parser.add_argument(
        "--show-config",
        action="store_true",
        help="Print resolved provider, endpoint, model, proxy and compatibility settings.",
    )
    args = parser.parse_args()
    if args.show_config:
        print(json.dumps(redacted_api_settings(), ensure_ascii=False, indent=2))
        try:
            resolve_api_key()
            print("API key: configured")
        except ValueError as exc:
            print(f"API key: missing ({exc})")
            return 2
        return 0
    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())

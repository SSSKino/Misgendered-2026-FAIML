# Multi-provider API adapter

The experiment runner now uses `src/llm_api.py` as a single HTTP adapter for:

- OpenAI Chat Completions
- Google Gemini OpenAI-compatible Chat Completions
- Anthropic native Messages API
- DeepSeek Chat Completions
- Alibaba Cloud Model Studio OpenAI-compatible Chat Completions
- Xiaomi MiMo OpenAI-compatible Chat Completions

## Configuration

Set a full request URL rather than only a base URL:

```env
RECRUITMENT_API_URL=https://api.openai.com/v1/chat/completions
RECRUITMENT_API_MODEL=your_model
RECRUITMENT_API_KEY=your_key
```

Provider-specific API key environment variables are also supported. See `config/.env.example` and `config/providers/`.

## Protocol conversion

OpenAI-compatible endpoints receive:

```json
{
  "model": "...",
  "messages": [
    {"role": "system", "content": "..."},
    {"role": "user", "content": "..."}
  ]
}
```

Anthropic receives:

```json
{
  "model": "...",
  "system": "...",
  "messages": [
    {"role": "user", "content": "..."}
  ],
  "max_tokens": 4096
}
```

## Compatibility fallbacks

For OpenAI-compatible gateways, the adapter can retry parameter compatibility failures by removing `response_format`, removing `temperature`, and switching between `max_tokens` and `max_completion_tokens`.

## Validation

Run:

```bash
python -m unittest -v tests/test_llm_api.py
python src/llm_api.py --show-config
python src/test_api_connection.py
```
